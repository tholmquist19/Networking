#! /usr/bin/bash


printf "httpforever using domain name"
printf "\n"
sudo ./lab7.py "http://httpforever.com/"
printf "\n"
printf "httpforever using url"
printf "\n"
sudo ./lab7.py 146.190.62.39
printf "\n"
printf "dominos"
printf "\n"
sudo ./lab7.py "https://www.dominos.com/en/"
printf "\n"
printf "yahoo"
printf "\n"
sudo ./lab7.py "https://www.yahoo.com/"


